package com.rakuten.training.basics;
/*
package practice;

public class inheritance_all {


public class Vehicle {
    
    public void start() {
        System.out.println("{{{{{{{{{{ Vehicle Starting }}}}}}}}}}");
    }

    public void stop() {
        System.out.println("{{{{{{{{{{ Vehicle Stopping }}}}}}}}}}");
    }
}



-------------------------------------



public class Driver {

    public void testDrive(Vehicle v) {
        v.start();
        System.out.println("-------- Wroooom ---------");

        if (v instanceof Truck) {
            Truck t = (Truck) v;
            t.honkHorribly();
        }

        v.stop();
    }

}



----------------------------------------


public class VehicleApp {

    public static void main(String[] args) {
        Driver d = new Driver();
        Vehicle v = new Vehicle();
        
        d.testDrive(v);

    }

}


-------------------------------------------------


public class Car {
    
    public void start() {
        System.out.println("<<<<<<<< Car STarting!! >>>>>>>>");
    }
    
    public void stop() {
        System.out.println("<<<<<<<< Car Stopping >>>>>>>>");
    }

    //1000's of lines of car specific logic
}


-----------------------------------------



public class Truck extends Vehicle {
    
    
    
    public void honkHorribly() {
        System.out.println("[[[[[[[[[[[ BBBBBOOOOOOOOOMMMMMMMMMPPPPP ]]]]]]]]]]]");
    }

}


---------------------------------


public class RadioactiveElement extends ChemicalElement {

    int halfLife;
    
    public RadioactiveElement(int atomicNumber,String symbol,String name,int halflife) {
        super(atomicNumber, symbol, name);
        this.halfLife = halflife;
    }
    
    public int getHalfLife() {
        return halfLife;
    }
    
}

}

*/
