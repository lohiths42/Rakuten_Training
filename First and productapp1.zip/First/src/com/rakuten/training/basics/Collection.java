package com.rakuten.training.basics;

import java.awt.List;
import java.util.ArrayList;

public class Collection {
	public static void main(String[] args) {
	//	demoRaw();
		demospecific();
	}
	
	
	private static void demoRaw() {
		ArrayList<String> l= new ArrayList<String>();
		l.add("312 ssuup?");
		l.add("21");
		
		
		System.out.println(l.get(0));
	}
	private static void demospecific() {
		ArrayList<Integer> ilist  = new  ArrayList<Integer>();
		ilist.add(21);
		
		Integer iObj = ilist.get(0);
		
		
	}
}
