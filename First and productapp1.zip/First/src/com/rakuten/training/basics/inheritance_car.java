package com.rakuten.training.basics;

public class inheritance_car extends inheritance_vehicle{
	public inheritance_car() {
		//super();  (this line would have been added by compiler)
	}
	
	public void start_vehicle() {  //overriding
		System.out.println("<<<<<<< Car starting >>>>>>>");
	}
	
	public void stop_vehicle() {
		System.out.println("<<<<<<< Car stopping >>>>>>>");
	}
}
