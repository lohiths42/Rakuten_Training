package com.rakuten.training.basics;

public class StackFullException extends RuntimeException {

	public StackFullException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	
}
