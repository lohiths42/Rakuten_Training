package com.rakuten.training.basics;
import java.io.*;


public class first {
	// 0,false,null
		int count;
		static int si;
		String name;
		boolean registered;
		
		public static void main(String[] args) {
			int i=10;
//			System.out.println(i);
			i++;
			System.out.println(i);
		}
		
}
