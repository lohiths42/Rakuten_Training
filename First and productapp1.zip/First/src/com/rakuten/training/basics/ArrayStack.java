package com.rakuten.training.basics;

public class ArrayStack implements Stack {

	private Object[] contents;
	private int top=-1;
	
	public ArrayStack(int capacity) {
		contents = new Object[capacity];
		
		
	}

	@Override
	public void push(Object anElement) {
		try {
		contents[++top]=anElement;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			
			throw new StackFullException("Stack capacity = "+contents.length+",already full", e);
		}
		
	}

	@Override
	public Object pop() {
		
		return contents[top--];
	}
	
}
