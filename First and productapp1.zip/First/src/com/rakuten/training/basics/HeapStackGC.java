package com.rakuten.training.basics;

//this program is used for understanding if the object 
//is going to be garbage collected or not
public class HeapStackGC {
	public static void method1() {
		DOWFinder ref2 = new DOWFinder();
		//do something with ref2
	}
	public static void main(String[] args) {
		//one stackframe is for this main method
		int i=10;
		DOWFinder ref1 = new DOWFinder();
		method1();   //another stackframe is created when
					// a method is invoked
		System.out.println("Done!!!");
		
	}
}
