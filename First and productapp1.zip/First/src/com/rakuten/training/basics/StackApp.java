package com.rakuten.training.basics;

public class StackApp {
	public static void main(String[] args) {
		ArrayStack st = new ArrayStack(5);
		StackUser u = new StackUser();
		
		u.fill(st);
			
	}
}
