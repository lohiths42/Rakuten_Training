package com.rakuten.training.basics;

public interface Stack {

	public void push(Object anElement);
	public Object pop();
	
}
