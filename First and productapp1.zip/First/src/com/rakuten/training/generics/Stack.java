package com.rakuten.training.generics;

public interface Stack<E> {

	public void push(E anElement);
	public E pop();
	
}
