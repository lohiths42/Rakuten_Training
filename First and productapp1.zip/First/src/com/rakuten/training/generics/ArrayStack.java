package com.rakuten.training.generics;

public class ArrayStack<E> implements Stack<E> {

	private Object[] contents;
	private int top=-1;
	
	public ArrayStack(int capacity) {
		contents = new Object[capacity];
		
		
	}

	public void push(E anElement) {
		try {
		contents[++top]=anElement;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			
			throw new StackFullException("Stack capacity = "+contents.length+",already full", e);
		}
		
	}

	public E pop() {
		
		return (E) contents[top--];
	}
	
}
