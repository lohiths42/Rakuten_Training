package com.rakuten.training.generics;

import java.util.Scanner;
import java.util.Set;


public class HashSet {
	public static void main(String [] args) {
	Set<String> uniqueWords = new java.util.HashSet<>();
	Scanner kb = new Scanner(System.in);
	
	while(true) {
		System.out.println("ENter the word");
		String aWord = kb.nextLine();
		if(aWord.equalsIgnoreCase("quit")) {
			break;
		}
		if(!uniqueWords.add(aWord)) {
			System.out.println("Duplicate added");
			
		}
		
	}
	System.out.println("All words");
	for(String a: uniqueWords) {
		System.out.println(a+"\n");
	}
	}
}
