package com.rakuten.training.generics;

import java.util.ArrayList;
import java.util.List;

public class genericsDemo {

	public static void main(String[] args) {
		Object o = new Integer(42);
		List l =  new ArrayList();
		ArrayList<Integer> iList = new ArrayList<Integer>();
		iList.add(12);
		iList.add(2341);
		System.out.println(iList);
		
		//List<Object> oList = new ArrayList<>();
	}
}
