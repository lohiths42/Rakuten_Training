package com.rakuten.training.generics;

import java.util.HashMap;


public class Map {
	public static void main(String[] args) {
		simpleMap();
	}
	
	private static void simpleMap() {
		HashMap<String,Integer> runs = new HashMap<>();
		runs.put("Vir",21);
		runs.put("he",321);
		runs.put("fhda",23);
		
		System.out.println("Do we have virat runs?"+ runs.get("Vir"));
		
	}
}
