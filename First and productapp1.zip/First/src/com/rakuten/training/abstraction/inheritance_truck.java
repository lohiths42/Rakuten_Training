package com.rakuten.training.abstraction;

public class inheritance_truck extends inheritance_vehicle{
	
	// this is one of the annotations in Java (above or to left of)
	// these are used to avoid any possible typo errors 
	//in the methods' names
	//1st reason - ensures that this indeed overrides a parent method
	//2nd reason - is to give an idea to the viewer that this is an override
	//@Override throws an error in case of mismatching method names
	@Override
	public void start_vehicle() {
		System.out.println("truck starting");
	}
	
	public void honk_horribly() {
		System.out.println("[[[[[ bbbbboooooooooooommmmmm]]]]]");
	}

	/* we do the below addition of unimplemented method if the base class
	 * is an abstract class
	 */
	@Override
	public void stop_vehicle() {
		// TODO Auto-generated method stub
		System.out.println("abstract_stop_vehicle");	
	}
}
