package com.rakuten.training.abstraction;

public class inheritance_driver {
	public void testDrive(inheritance_vehicle v) {
		v.start_vehicle();  //goes to overridden version of start_vehicle
		//abstract classes are designed to be polymorphic
		
		System.out.println("--------WROOM--------");
		
		if(v instanceof inheritance_truck) {
		inheritance_truck t = (inheritance_truck) v;
		//explicit type casting
		// this leads to runtime class-cast exception
		// we cannot typecast between two siblings (eg: car and truck)
		t.honk_horribly();
		}
		v.stop_vehicle();
		
	}
}
