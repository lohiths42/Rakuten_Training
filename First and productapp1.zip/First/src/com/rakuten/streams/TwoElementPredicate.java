package com.rakuten.streams;
//DRY - Don't Repeat Yourself

@FunctionalInterface
public interface TwoElementPredicate<E> {
	public boolean is_first_better_than_second(E first, E second);
	
	public default void a_default_method() {
		System.out.println("Default!!");
	}
	
}
